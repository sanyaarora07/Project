from django.contrib.auth.models import User
from django_filters.rest_framework import DjangoFilterBackend
import django_filters
from django.http import HttpResponse
from django.shortcuts import get_object_or_404
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework import generics
from rest_framework.decorators import permission_classes
from rest_framework.generics import *
from rest_framework.serializers import ModelSerializer
from rest_framework import permissions
from rest_framework.views import APIView
from rest_framework import generics,status
from rest_framework.viewsets import ModelViewSet
from .serializer import HotelSerializer,RoomSerializer,BookingSerializer,ContactSerializer
from .signals import checkoutroomsavailable,UpdateToalrooms
from Hotel.paginations import CustomPagination
from datetime import datetime
from Hotel.models import Hotel,Room,Booking,Checkout,Contact

#Crud for admin
class HotelViewSet(ModelViewSet):
    #  permission_classes = [permissions.IsAuthenticated,permissions.IsAdminUser]
     serializer_class = HotelSerializer
     queryset = Hotel.objects.all()
     pagination_class = CustomPagination

     def create(self, request, *args, **kwargs):
        try:
          return super().create(request, *args, **kwargs)
        except Exception as e:
             print(e)
               
          
#Crud for admin
class RoomViewSet(ModelViewSet):
    #  permission_classes = [permissions.IsAuthenticated,permissions.IsAdminUser]
     queryset=Room.objects.all()    
     serializer_class=RoomSerializer
     pagination_class = CustomPagination
     def create(self, request, *args, **kwargs):
        try:
          return super().create(request, *args, **kwargs)
        except Exception as e:
             print(e)
               

#for user only
class RoomListView(ListAPIView):
     serializer_class=RoomSerializer
     pagination_class = CustomPagination       

     def get_queryset(self):
            hotel=self.kwargs.get('pk')
            room=Room.objects.filter(hotel_id=hotel)
            return room



class SinglroomView(RetrieveAPIView):
    serializer_class=RoomSerializer
    queryset = Room.objects.all()
    pagination_class = CustomPagination       

    

class SinglroombookView(RetrieveAPIView):
    serializer_class=BookingSerializer
    queryset = Booking.objects.all()
    pagination_class = CustomPagination  
      






'''
for user only

'''
class HotelListView(ListAPIView):
    #  permission_classes = [permissions.IsAuthenticated]
     queryset=Hotel.objects.all()    
     serializer_class=HotelSerializer
     
     def list(self, request, *args, **kwargs):
            queryset = self.get_queryset()
            serializer = self.get_serializer(queryset, many=True)
            data = serializer.data
            return Response(data)
                       



'''
search Hotel

'''
class HotelsFilterSet(django_filters.FilterSet):
    name= django_filters.CharFilter(lookup_expr='contains')
    class Meta:
        model = Hotel
        fields = ['name']

class SearchHotelssViewSet(ListCreateAPIView):
    serializer_class =HotelSerializer
    queryset = Hotel.objects.all()
    filter_backends = [DjangoFilterBackend]
    filterset_class=HotelsFilterSet


'''
hotel booking

'''

class HotelBookedView(ListCreateAPIView):
    permission_classes = [permissions.IsAuthenticated] 
    serializer_class=BookingSerializer
    def get_queryset(self):
            bookings = Booking.objects.filter(guest=self.request.user)
            return bookings
    def create(self, request, *args, **kwargs):
            try:
                room = request.data['room']
                rooms = Room.objects.get(id=room)
                required = request.data['room_required']
                left_room=rooms.no_of_beds-required
                if  rooms.no_of_beds == 0 or rooms.no_of_beds <=0:
                        return Response({"msg":"All rooms Booked"})
                elif left_room<0:
                            return Response({"msg":"Sorry you cant book   "})
                else:
                    no_of_people = request.data['no_of_guests']
                    room = Room.objects.get(id=request.data['room'])
                    room_capacity = room.capacity
                    required = request.data['room_required']
                    if room_capacity <= no_of_people:
                            single_room_capacity = round(int(no_of_people)/ int(room.capacity)) 
                            print(single_room_capacity)
                            if required < single_room_capacity:
                                return Response({"msg":"Please add more room, as guest are more"})
                            elif required > single_room_capacity:
                                return Response({"msg":"Please add less  room, as guest are less"})
                            else:
                                request.data['guest'] = request.user.id
                                res = super().create(request, *args, **kwargs)
                                res.data = {"msg":"Successfully Booked"}  
                              
                    else:
                        request.data['guest'] = request.user.id
                        request.data['room_required'] = 1
                        res = super().create(request, *args, **kwargs)
                        res.data = {"msg":"Successfully Booked"}
                    return res
            except Exception as e:
                      return Response({'error' : str(e)},status=500)
    
             




#hotel Checkout
class CheckoutRoom(APIView):
    # permission_classes = [permissions.IsAuthenticated]
    def post(self, request,pk):
        try:
            rooms=Booking.objects.filter(hotel=pk, guest_id=request.user.id)
            if  rooms.exists():
                for hotel in rooms:
                    Checkout.objects.create(room=hotel.room, guest=hotel.guest, hotel=hotel.hotel, booking=hotel)
                return Response({"msg":"Checkout Successfully"})
            else:
                 return Response({"msg":"Room  not exist"})
        except Exception as e:
           return Response({'error' : str(e)},status=500)
    
             

class ContactUs(APIView):
     permission_classes = [permissions.IsAuthenticated]
     queryset=Contact.objects.all()  
     serializer_class=ContactSerializer
     def post(self, request, *args, **kwargs):
            serializer = ContactSerializer(data=request.data)
            if serializer.is_valid():
                serializer.save()
                return Response(serializer.data, status=status.HTTP_201_CREATED)
            else:
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
            
                             




class CancelBooking(APIView):
    queryset=Booking.objects.all()  
    serializer_class=BookingSerializer

    def post(self, request, pk):
        try:
            booking = Booking.objects.get(id=pk)
        except Booking.DoesNotExist:
            return Response({'detail': 'Booking does not exist.'}, status=status.HTTP_404_NOT_FOUND)

        return Response({
            'detail': 'Booking cancelled successfully.'}, status=status.HTTP_200_OK)

    

    