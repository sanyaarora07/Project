   
from django.contrib import admin
from django.urls import path,include
from django.conf import settings
from .views import HotelViewSet,RoomViewSet,RoomListView,HotelListView,SearchHotelssViewSet,HotelBookedView,CheckoutRoom,ContactUs,CancelBooking,SinglroomView,SinglroombookView
from rest_framework.routers import DefaultRouter

router = DefaultRouter()
router.register('hotel', HotelViewSet, basename='hotel')
router.register('room', RoomViewSet, basename='room')

urlpatterns = [
    path('',include(router.urls)),
    path('rooms/<int:pk>',RoomListView.as_view(),name='roomlist'),
    path('rooms/room/<int:pk>/',SinglroomView.as_view(),name='roomlist'),
    path('hotels/',HotelListView.as_view(),name='hotellist'),
    path('hotelsearch',SearchHotelssViewSet.as_view(),name='SearchHotels'),
    path('booking',HotelBookedView.as_view(),name='Hotelbooked'),
    #path('booking/<int:pk>',BookedRetrieveUpdateDestroy.as_view(),name='RetrieveUpdateDestroy'),
    path('bookings/<int:pk>/checkout',CheckoutRoom.as_view(),name='checkout'),
    #path('hotelCheckAvailability',CheckAvailability.as_view(),name='CheckAvailability'),
    path('hotel',ContactUs.as_view(),name='hotelcontact'),
    path('hotels/<int:pk>',CancelBooking.as_view(),name='CancelBooking'),
    path('bookingss/book/<int:pk>',SinglroombookView.as_view(),name='roomlist'),

    


]