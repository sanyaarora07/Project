from rest_framework import serializers
from Hotel.models import Hotel,Room,Booking,Contact

class HotelSerializer(serializers.ModelSerializer):
        status = serializers.SerializerMethodField()
        class Meta:
                model = Hotel
                fields = '__all__'

        def get_status(self, obj):
                print(obj.room_available)
                if obj.room_available == 0:
                        print("yes")
                        status = "Hotel is full!"
                        obj.is_available = False
                        obj.save()
                else:
                        obj.is_available = True
                        obj.save()
                        status = "Available"
                return status



class RoomSerializer(serializers.ModelSerializer):
    # hotel=HotelSerializer(read_only=True)
    class Meta:
            model = Room
            fields = '__all__'


class BookingSerializer(serializers.ModelSerializer):

    class Meta:
            model = Booking
            fields = '__all__'
    


class ContactSerializer(serializers.ModelSerializer):
    class Meta:
            model = Contact
            fields = '__all__'
