from django.db.models import signals
from django.core.mail import send_mail
from django.conf import settings
from django.http import JsonResponse
from django.dispatch import receiver
from django.template.loader import render_to_string
from django.db.models.signals import post_save
from .models import Hotel,Room,Booking,Checkout
from rest_framework.response import Response
from django.template.loader import get_template



# @receiver(post_save, sender=Booking)
# def send_email_on_save(sender, instance, created, **kwargs):
#     email_html = get_template('signal.html')
#     context = {'guest': instance.guest, 'hotel': instance.hotel}
#     if created:
#         subject = 'Congratulations!! Your Hotel is Booked '
#         message = f'ROOM BOOKED  {instance.id} was created.'
#         html_message = email_html.render(context)
#         email_from=settings.EMAIL_HOST_USER
#         recipient_list = [instance.guest.email]
#         send_mail(subject, message, email_from, recipient_list, html_message=html_message)



@receiver(post_save, sender=Checkout)
def checkoutroomsavailable(sender, instance, **kwargs):
            hotel=Hotel.objects.get(id=instance.hotel.id)#15
            hotel_booked=Booking.objects.get(id=instance.booking.id)#136
            booked=hotel_booked.room_required
            print(booked)
            hotel.room_available+=booked
            hotel.save()


#after booked room available
@receiver(post_save, sender=Booking)
def UpdateToalrooms(sender, instance, **kwargs):
                room_required = instance.room_required
                print(room_required)
                room = Room.objects.get(id=instance.room.id)
                print(room)
                room.no_of_beds -= room_required
                room.save()
                hotel=Hotel.objects.get(id=instance.hotel.id)#15
                print(hotel.id)
                hotel.room_available-=room_required
                print(hotel.id)
                hotel.save()


# #room will add 
# @receiver(post_save, sender=Room)
# def addrooms(sender, instance, **kwargs):
#             hotel=Hotel.objects.get(id=instance.hotel.id)
#             print(hotel)
#             hotel.rooms+=1
#             hotel.save()
 # id=[h.id for h in hotel]