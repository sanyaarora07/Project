from django.db import models
from Accounts.models import Profile
from django.contrib.auth.models import User
from django.utils import timezone

# Create your models here.

class Hotel(models.Model):
    name = models.CharField(max_length=200)
    phone=models.CharField(max_length=10)
    city= models.CharField(max_length=200)
    state = models.CharField(max_length=200)
    zip_code = models.CharField(max_length=10)
    is_available=models.BooleanField(default=True)
    total_rooms=models.IntegerField(null=True)
    room_available = models.IntegerField(null=True)#availrooms
    image = models.ImageField(upload_to='picture',blank=True,null=True)
    



    def __str__(self):
        return self.name

class Room(models.Model):
    ROOM_TYPES = (
        ('Luxury', 'Luxury'),
        ('Normal', 'Normal'),
        ('Economic', 'Economic'),

    )
    hotel=models.ForeignKey(Hotel,null=True,on_delete=models.CASCADE)
    room_type=models.CharField(max_length=200,choices=ROOM_TYPES, default='Normal')
    capacity = models.SmallIntegerField(null=True)#room rype capcity
    price=models.FloatField(null=True)
    is_available=models.BooleanField(default=True)
    no_of_beds=models.IntegerField(default=1,null=True)
    roomfacilities=models.CharField(max_length=200,null=True)
    image = models.ImageField(upload_to='picture',blank=True,null=True)
   
    def __str__(self):
        return self.room_type

class Contact(models.Model):
    name=models.CharField(max_length=100)
    email=models.CharField(max_length=100)
    message=models.TextField(max_length=2000)
    def __str__(self):
        return self.name
    

class Booking(models.Model):
    # guest_name=models.CharField(max_length=200)
    room=models.ForeignKey(Room,on_delete=models.CASCADE)
    guest=models.ForeignKey(User,on_delete=models.CASCADE)
    hotel=models.ForeignKey(Hotel,on_delete=models.CASCADE)
    checkin_date=models.DateTimeField()
    checkout_date = models.DateTimeField()
    no_of_guests=models.IntegerField(default=1)
    room_required=models.IntegerField(default=1)


    def __str__(self):
        return self.guest

class Checkout(models.Model):
    room=models.ForeignKey(Room,on_delete=models.CASCADE,null=True)
    guest=models.ForeignKey(User,on_delete=models.CASCADE,null=True)
    hotel=models.ForeignKey(Hotel,on_delete=models.CASCADE,null=True)
    booking=models.ForeignKey(Booking,on_delete=models.CASCADE,null=True)
    checkout=models.BooleanField(default=True)
    rating = models.PositiveIntegerField(blank=True, null=True)
