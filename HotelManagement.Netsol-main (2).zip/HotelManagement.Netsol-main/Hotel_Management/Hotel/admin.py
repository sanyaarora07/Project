from django.contrib.auth.models import User
from django.contrib import admin
from .models import Room,Booking,Hotel


# Register your models here.
class RoomInline(admin.TabularInline):
    model = Room
    readonly_fields = ('id','room_type','price','no_of_beds','roomfacilities')
    extra=1
class HotelAdmin(admin.ModelAdmin):
    list_display = ['name', 'phone','city','state','zip_code','is_available']
    inlines = [RoomInline]

    class Meta:
        model = Hotel
   
class BookingAdmin(admin.ModelAdmin):
    model = Booking
    list_display = ['checkin_date','checkout_date','no_of_guests']
    
admin.site.register(Room)
admin.site.register(Booking, BookingAdmin)
admin.site.register(Hotel, HotelAdmin)
