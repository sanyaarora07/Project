from django.contrib import admin
from .models import Profile
class Profileadmin(admin.ModelAdmin):
    model=Profile
    list_display=('user','address','email','age','gender','phone_no')
# Register your models here.
admin.site.register(Profile)


