from django.contrib.auth.models import User
from django.contrib.auth import authenticate,login as auth,logout
from django.shortcuts import render
from Hotel.models import Booking
from .serializer import UserRegistrationSerializer,ChangePasswordSerializer,UserSerializer
from Hotel.serializer import BookingSerializer
from Accounts.serializer import ProfileSerializer
from rest_framework.response import Response
from rest_framework import serializers,status
from rest_framework import permissions
from rest_framework.permissions import IsAuthenticated 
from rest_framework.decorators import api_view,permission_classes
from rest_framework.views import APIView
from rest_framework .generics import ListAPIView,ListCreateAPIView,CreateAPIView
from rest_framework_simplejwt.authentication import JWTAuthentication
from rest_framework.authtoken.models import Token
from .signal import password_reset

# Create your views here



class RegisteredView(ListCreateAPIView):
    queryset=User.objects.all()
    serializer_class=UserSerializer
    serializer_class = UserRegistrationSerializer
    template_name="login.html"
    def get(self,request):
         return render(request.self.template_name)


    def create(self, request):
            try:
                email=request.data['email']
                user_email= User.objects.get(email=email)
                print("user_email.email")
                user_email.email==email
                return  Response({'message': 'email already registered '})
            except :
                serializer = self.serializer_class(data=request.data)
                serializer.is_valid(raise_exception=True)
                serializer.save()
                return Response({'message': ' Registered successfully'}, status=status.HTTP_201_CREATED)
    

        

@api_view(http_method_names=('post',))
def login_user(request):
    username=request.data['username']
    password=request.data['password']
    user=authenticate(request,username=username,password=password) 

    auth(request,user)
    user= User.objects.get(username=username)
   
    token=Token.objects.create(user=user)
    return Response({'token':token.key,'username':username},status=status.HTTP_200_OK)


@api_view()
@permission_classes([IsAuthenticated])
def logout_users(request):
    try:
        token=Token.objects.get(user_id=request.user.id)
        token.delete()
        logout(request)
    except:
        return Response({'message':" NOT_LOGGED_OUT"})
    return Response({'user':"LOGGED_OUT"})    

class ProfileList(ListAPIView):
    permission_classes = [permissions.IsAuthenticated]
    serializer_class=BookingSerializer

    def get_queryset(self):
        user=self.request.user
        r=Booking.objects.filter(guest=user)
        return r
    
class UserProfileList(CreateAPIView):
    permission_classes = [permissions.IsAuthenticated]
    serializer_class=ProfileSerializer

    def create(self, request, *args, **kwargs):
        print(request.user.id)
        request.data['user']=request.user.id
        response = super().create(request, *args, **kwargs)
        return Response ({'id':response.data['id'],'msg':'profile updated'})

    

class ChangePasswordView(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request): 
            serializer = ChangePasswordSerializer(data=request.data, context = {'user':request.user})           
            if serializer.is_valid():
                return Response({"msg":"changed succesfully"})
            return Response(serializer.errors,
                            status=status.HTTP_400_BAD_REQUEST)
    
