from django.contrib import admin
from django.urls import path
from django.conf import settings 
from .views import *
from .import views


urlpatterns = [
    path('profile/',RegisteredView.as_view(),name='register'),
    path('login_usertoken/',login_user,name='loginusertoken'),
    path('logout_usertoken/',logout_users,name='logoutusertoken'),
    path('user/',ProfileList.as_view(),name='profile'),
    path('changePassword/',ChangePasswordView.as_view(),name='Password'),
    path('userprofile/',UserProfileList.as_view(),name='UserProfileList'),

    

    

]