//login
            function showToastr() {
                toastr.options = {
                    positionClass: "toast-center",
                    progressBar: true,
                    closeButton: true,
                    onHidden: function () {
                        window.location.href = 'index.html'; // Redirect to index.html
                    }
                };
                toastr.success('Login successfully ');
            }
            function getCookie(name) {
                var cookieName = name + "=";
                var decodedCookie = decodeURIComponent(document.cookie);
                var cookieArray = decodedCookie.split(';');
                for (var i = 0; i < cookieArray.length; i++) {
                    var cookie = cookieArray[i];
                    while (cookie.charAt(0) == ' ') {
                        cookie = cookie.substring(1);
                    }
                    if (cookie.indexOf(cookieName) == 0) {
                        return cookie.substring(cookieName.length, cookie.length);
                    }
                }
                return "";
            }
            var username = getCookie('username');
            $(document).ready(function() {
                if (username) {
                    $('#navbar-username').html('<span class="username">Welcome, ' + username + '</span><i class="fa fa-user"></i> &#x1F60D;');
            
            }

        

              $('#form').submit(function(event) {
                event.preventDefault();
                $.ajax({
                  url: ' http://127.0.0.1:8000/accounts/login_usertoken/',
                  method: 'POST',
                  data: {
                  username: $("#username").val(),
                  password: $("#password").val()
                  
                    
                  },
               
                  success: function(data) {
                    console.log(data)
                      console.log(data['token'])
                      showToastr();
                      

                      
                    // Store token in cookie with 7 day expiration
                    var now = new Date();
                    now.setTime(now.getTime() + (9 * 24 * 60 * 60 * 1000));
                   document.cookie = 'auth_token=' + data.token + '; expires=' + now + '; path=/';
                  document.cookie = 'username=' + data.username + '; expires=' + now + '; path=/';
                 
                  //window.location.href = 'index.html';
                  },
                  error:function(error){
                    console.log(error)
                    toastr.error('Invalid credentials')
                  }
                
                });
              });
            });
            