
 function getCookie(name) {
        var cookieName = name + "=";
        var decodedCookie = decodeURIComponent(document.cookie);
        var cookieArray = decodedCookie.split(';');
        for (var i = 0; i < cookieArray.length; i++) {
            var cookie = cookieArray[i];
            while (cookie.charAt(0) == ' ') {
                cookie = cookie.substring(1);
            }
            if (cookie.indexOf(cookieName) == 0) {
                return cookie.substring(cookieName.length, cookie.length);
            }
        }
        return "";
    }

    // logout 
$(document).ready(function(e) {

        var token = getCookie('auth_token');
        
        $('#logout-link').click(function(e)
        {
            console.log(token)
            e.preventDefault()
            console.log("logout !")
              // Send AJAX request to the backend endpoint
              $.ajax({
                url: 'http://127.0.0.1:8000/accounts/logout_usertoken/', 
                method: 'GET', 
                headers: {
                    "Authorization": 'Token ' + token
                },
                success: function(res) {
                    console.log(res)
                    // Handle the success response
                    console.log('Token deleted successfully');
                    var now = new Date();
                    document.cookie = 'auth_token=' + null + '; expires=' + now + '; path=/';
                    document.cookie = 'username=' + '; expires=' + now + '; path=/';
                    location.reload()
                    if (token == 'null') { // logout 
                    //$('#navbar-username').text(username);
                    $('#logout-link').hide();
                    $('#login-link').show();
            
                    } else {
                        // logined
                    $('#logout-link').show();
                    $('#login-link').hide();
                    
                    } 
              
                },
                error: function(error) {
                    console.log(error)
                }
            });

             
            
            });


        })
       




// show navbar acc to logged in user
    $(document).ready(function() {
        var token = getCookie('auth_token');
        
             if (token == 'null') { // logout 
             //   $('#navbar-username').text(username);
               $('#logout-link').hide();
               $('#login-link').show();
     
             } else {
                 // logined
               $('#logout-link').show();
               $('#login-link').hide();
               
             }


        })
       