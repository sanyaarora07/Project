from django.shortcuts import render,redirect
from django.contrib.auth import authenticate, login
from django.contrib.auth.models import User
from django.contrib import messages

# Create your views here.



def login_view(request):
    if request.method == 'POST':
        email = request.POST.get('email')
        password = request.POST.get('password')
        if not email:
            messages.error(request, 'Please enter your email')
        elif not password:
            messages.error(request, 'Please enter your password')
        else:
            try:
                user = User.objects.get(email=email)
                auth_user = authenticate(request, username=user.username, password=password)
                if auth_user is not None:
                    login(request, auth_user)
                    messages.success(request, 'Login successful')
                    return redirect('#')
                else:
                    messages.error(request, 'The email and password combination you entered is not correct. Please try again.')
            except User.DoesNotExist:
                messages.error(request, 'The email does not exist. Please try again with a valid email.')

    return render(request, 'login.html')


